﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WEBAPI2.Contract.Request;
using WEBAPI2.Contract.Response;
using WEBAPI2.Repository.contract;

namespace WEBAPI2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccoutController : ControllerBase
    {
        private IUsers userSeverce;
        public AccoutController(IUsers users)   
        {
            userSeverce = users;
        }
        [HttpPost]
        [Route("SignIn")]
        public IActionResult SignIn(SignInModel model)
        {
            if(model!=null)
            {
                var user = userSeverce.SignIn(model);
                var apiResponse = new ApiResponse();
                if(user==null)
                {
                    //not found failure
                    apiResponse.Ok = false;
                    apiResponse.Status = 404;
                    apiResponse.Message = "Invalid login credentials";
                    return Ok(apiResponse);

                }
                else
                {
                    // Success login
                    apiResponse.Ok = true;
                    apiResponse.Status = 200;
                    apiResponse.Message = " Login Success";
                    apiResponse.Data = user;
                    apiResponse.Token = "?";
                    return Ok(apiResponse);
                }
            }
            else
            {
                return BadRequest();
            }
        }
        [HttpPost]
        [Route("SignUp")]
        public IActionResult SignUp(SignUpModel model)
        {
            if (model != null)
            {
                var user = userSeverce.SignUp(model);
                var apiResponse = new ApiResponse();
             
                  
                    apiResponse.Ok = true;
                    apiResponse.Status = 200;
                    apiResponse.Message = " user created Successfully !";
                    apiResponse.Data = user;
                    return Ok(apiResponse);
            }
            else
            {
                return BadRequest();
            }
        }
    }
}
