﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WEBAPI2.model;
using WEBAPI2.Repository.contract;

namespace WEBAPI2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {

        private IEmployee employeeService;

        public EmployeesController(IEmployee employee)
        {
            employeeService = employee;
        }
        [HttpGet]
        [Route("GetAllEmployee")]
        public IActionResult GetAllEmployee()
        {
            var results = employeeService.GetEmployees();
            if (results.Count > 0)
            {
                return Ok(results);
            }
            else
            {
                return NotFound("Data not found !");
            }
        }
        [HttpGet]
        [Route("GetEmployeeById/{id}")]
        public IActionResult GetEmployeeById(int id)
        {
            var results = employeeService.GetEmployeeById(id);
            if (results!=null)
            {
                return Ok(results);
            }
            else
            {
                return NotFound("Data not found !");
            }
        }
        [HttpPost]
        [Route("Create")]
        public IActionResult Post(Employee employee)
        {
           var emp =  employeeService.PostEmployee(employee);
            if(emp!=null)
            {
                return Ok(emp);
            }
            else
            {
                return NotFound();
            }
            return null;
        }
        [HttpDelete]
        [Route("DeleteEmployee/{id}")]
        public IActionResult Delete(int id)
        {
            if(id == 0)
            {
                return BadRequest();
            }
            else
            {
                var emp = employeeService.deleteEmployee(id);
                if(emp!=null)
                {
                    return Ok(emp);
                }
                else
                {
                    return NotFound();
                }
            }
        }

        [HttpPut]
        [Route("UpdateEmployee")]
        public IActionResult Update(Employee employee)
        {
            if(employee==null)
            {
                return BadRequest();
            }
            else
            {
                var emp = employeeService.UdateEmployee(employee);
                if(emp!=null)
                {
                    return Ok(emp);
                }
                else
                {
                    return NotFound();
                }
            }
        }
    }

}
