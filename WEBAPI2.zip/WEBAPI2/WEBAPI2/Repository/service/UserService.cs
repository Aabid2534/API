﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WEBAPI2.Contract.Request;
using WEBAPI2.model;
using WEBAPI2.Repository.contract;

namespace WEBAPI2.Repository.service
{
    public class UserService : IUsers
    {
        private ApplicationDbContext dbContext;

        public UserService(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        /* 
           RUtrun bool type 
         public bool SignIn(SignInModel model)
         {
             if (dbContext.User.Any(e => e.Email == model.Email && e.Password == model.Password))
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }*/

        public Users SignIn(SignInModel model)
        {
            var user = dbContext.User.SingleOrDefault(e => e.Email == model.Email && e.Password == model.Password);
            if(user!=null)
            {
                return user;
            }
            else
            {
                return null;
            }
        }

        public Users SignUp(SignUpModel model)
        {
            var user = new Users()   // Assign Value
            {
                Name = model.Name,
                Email = model.Email,
                Password = model.Password,
                Gender = model.Gender
            };
            dbContext.User.Add(user);
            dbContext.SaveChanges();
            return user;
        }
    }
}
