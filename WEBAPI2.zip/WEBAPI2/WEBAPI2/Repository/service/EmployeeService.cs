﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WEBAPI2.model;
using WEBAPI2.Repository.contract;

namespace WEBAPI2.Repository.service
{
    public class EmployeeService : IEmployee
    {
        private readonly ApplicationDbContext dbContext;

        public EmployeeService(ApplicationDbContext _dbContext)
        {
                   
              dbContext = _dbContext;
        }

        public Employee deleteEmployee(int id)
        {
            var emp = dbContext.Employees.SingleOrDefault(e => e.Id == id);
            if(emp!=null)
            {
                dbContext.Employees.Remove(emp);
                dbContext.SaveChanges();
                return emp;
            }
            
            return null;
        }

        public Employee GetEmployee(Employee employee)
        {
            return employee;
        }

        public Employee GetEmployeeById(int id)
        {
            var emp = dbContext.Employees.SingleOrDefault(e => e.Id == id);
            return emp;
        }

        public List<Employee> GetEmployees()
        {
            return dbContext.Employees.ToList();
        }

        public Employee PostEmployee(Employee employee)
        {
            dbContext.Employees.Add(employee);
            dbContext.SaveChanges();
            return employee;
        }

        public Employee UdateEmployee(Employee emp)
        {
            var res = dbContext.Employees.SingleOrDefault(e => e.Id == emp.Id);
            if(res!=null)
            {
                res.Name = emp.Name;
                res.Email = emp.Email;
                res.password = emp.password;
                res.Mobile = emp.Mobile;
                dbContext.Employees.Update(res);
                dbContext.SaveChanges();
                return emp;
            }
            return null;

        }
    }
}

