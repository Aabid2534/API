﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WEBAPI2.Contract.Request;
using WEBAPI2.model;

namespace WEBAPI2.Repository.contract
{
    public interface IUsers
    {
        //bool SignIn(SignInModel model);

        Users SignIn(SignInModel model);

        Users SignUp( SignUpModel model);


    }
}
