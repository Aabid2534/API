﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WEBAPI2.model;

namespace WEBAPI2.Repository.contract
{
    public interface IEmployee
    {
        List<Employee> GetEmployees();

        Employee GetEmployee(Employee employee);

        Employee GetEmployeeById(int id);


        Employee PostEmployee(Employee employee);

        Employee deleteEmployee(int id);

        Employee UdateEmployee(Employee emp);
    }
}
